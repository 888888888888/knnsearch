package KWDProjekt;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Random;

public class KNN {

	// cena, zegar procesora, pamiec wbudowana, przekotna, RAM
	static double[][] zbiorUczacy = {
			// galaxy grand prime
			{ 612, 1.2, 8, 5, 1 },
			// galaxy S6
			{ 3340, 2.1, 32, 5.1, 3 },
			// galaxy J5
			{ 724, 1.2, 16, 5, 1.5 },
			// sony xperia z1
			{ 750, 2.2, 16, 5, 2 },
			// sony xperia z5
			{ 1998, 2.0, 32, 5.2, 3 }, };

	private String knnserach(String[] array) {
		// tworzenie HashSet na otrzymanej talbicy Stringow w celu zniwelowania
		// powtorzen
		HashSet<String> h = new HashSet<String>(Arrays.asList(array));
		// przeksztalcenie HashSet spowrotem do tablicy Stringow
		String[] uniqueValues = h.toArray(new String[0]);
		// liczba unikalnych wartosci
		int[] counts = new int[uniqueValues.length];
		// liczenie ile unikalne wartosci powtarzaja sie w maciezystej tablicy
		for (int i = 0; i < uniqueValues.length; i++) {
			for (int j = 0; j < array.length; j++) {
				if (array[j].equals(uniqueValues[i])) {
					counts[i]++;
				}
			}
		}

		for (int i = 0; i < uniqueValues.length; i++)
			System.out.println("Unikalne warto�ci -> " + uniqueValues[i] + " Suma -> " + counts[i]);

		// znajdowanie maksymalnej warto�ci wyst�pien
		int max = counts[0];
		for (int counter = 1; counter < counts.length; counter++) {
			if (counts[counter] > max) {
				max = counts[counter];
			}
		}
		System.out.println("maksymalna warto�� wyst�pienia: " + max);

		// znajdujemy ile razy "maksymalna warto�� wyst�pienia" powtarza si�
		// (przynajmiej raz)
		int freq = 0;
		for (int counter = 0; counter < counts.length; counter++) {
			if (counts[counter] == max) {
				freq++;
			}
		}

		// jesli jest tylko jedna maksymala wartosc,
		// czyli liczba sasiadow tej samej klasy nie jest taka sama to zwracamy
		// nasza klase
		int index = -1;
		if (freq == 1) {
			for (int counter = 0; counter < counts.length; counter++) {
				if (counts[counter] == max) {
					index = counter;
					break;
				}
			}
			return uniqueValues[index];
		} else {// jesli klasy sasadow sa takie same to losujemy jedna z nich i
				// ja zwracamy
			int[] ix = new int[freq];// tablica na te same klasy, z ktorej
										// bedziemy losowac
			int ixi = 0;
			for (int counter = 0; counter < counts.length; counter++) {
				if (counts[counter] == max) {
					ix[ixi] = counter;// jeszcze raz znajdujemy maksymalne
										// wartosci i je zapisujemy
					ixi++;
				}
			}

			for (int counter = 0; counter < ix.length; counter++) {

				System.out.println("Pasujace modele -> " + ix[counter]);
			}

			// wybieramy losowo
			Random generator = new Random();
			// losujemy od zera do maksymalnego indeksu naszej tablicy
			int rIndex = generator.nextInt(ix.length);
			System.out.println("Wylosowano ->" + ix[rIndex]);
			int nIndex = ix[rIndex];

			return uniqueValues[nIndex];
		}

	}

	public String wyszukajModel(double[] szukanyTelefon) {

		int k = 3;// liczba sasiadow
		// lista wszystkich telefonow i ich parametrow
		ArrayList<Telefon> telefonList = new ArrayList<Telefon>();
		// lista wynikow dla kazdego modela w jakim stopniu pasuje do szukanego
		ArrayList<Wynik> wynikList = new ArrayList<Wynik>();
		// add city data to cityList
		telefonList.add(new Telefon(zbiorUczacy[0], "galaxy"));
		telefonList.add(new Telefon(zbiorUczacy[1], "galaxy"));
		telefonList.add(new Telefon(zbiorUczacy[2], "galaxy"));
		telefonList.add(new Telefon(zbiorUczacy[3], "xperia"));
		telefonList.add(new Telefon(zbiorUczacy[4], "xperia"));

		for (Telefon telefon : telefonList) {
			double odleglosc = 0.0;
			// zaimplementowana odleg�o�� euklidesowa
			for (int j = 0; j < telefon.atrybuty.length; j++) {
				// mierzone odleglosci miedzy wartosciami ze zbioru uczacego a
				// wartoscia,
				// dla ktorej szukamy klasy
				odleglosc += Math.pow(telefon.atrybuty[j] - szukanyTelefon[j], 2);
			}
			double euklidesOdl = Math.sqrt(odleglosc);
			System.out.println(telefon.model + "->" + euklidesOdl);
			wynikList.add(new Wynik(euklidesOdl, telefon.model));
		}

		Collections.sort(wynikList, new sortujWgPrawdopodobienstwa());
		// brane jest pod uwage tylko k najbliszych s�siad�w
		String[] Ksasiadow = new String[k];
		for (int x = 0; x < k; x++) {
			System.out.println(wynikList.get(x).model + " .... " + wynikList.get(x).podobienstwo);
			// pobieranie wartosci z wynikowej kolekcji
			Ksasiadow[x] = wynikList.get(x).model;
		}
		String Class = knnserach(Ksasiadow);
		return "Najlepszy model telefonu to: " + Class;
	}

	// klasa do przechowywania modeli telefonow
	static class Telefon {
		double[] atrybuty;
		String model;

		public Telefon(double[] atrybuty, String model) {
			this.model = model;
			this.atrybuty = atrybuty;
		}
	}

	// klasa do przechowywania wynikow (podobienstwo telefonu, model telefonu
	static class Wynik {
		double podobienstwo;
		String model;

		public Wynik(double podobienstwo, String model) {
			this.model = model;
			this.podobienstwo = podobienstwo;
		}
	}

	// prosta klasa por�wnuj�ca warto�ci z klasy Result implemetujaca odpowiedni
	// interfejs
	static class sortujWgPrawdopodobienstwa implements Comparator<Wynik> {
		@Override
		public int compare(Wynik a, Wynik b) {
			return a.podobienstwo < b.podobienstwo ? -1 : a.podobienstwo == b.podobienstwo ? 0 : 1;
		}
	}

}
