package KWDProjekt;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.JToolBar;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.BevelBorder;

import KWDProjekt.KNN;

public class MainGUI extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	
	private JPanel pole;
	
	private TextField cena;
	private TextField zegarProcesora;
	private TextField pamiec;
	private TextField przekatna;
	private TextField ram;
	
	private JTextPane wynik;

	protected boolean cenaFlaga = false;

	protected boolean ramFlaga = false;

	protected boolean przekatnaFlaga = false;

	protected boolean pamiecFlaga = false;

	protected boolean zegarFlaga = false;
	
	public MainGUI() {
		// TODO Auto-generated constructor stub
		initComponents();
	}
	
	private void initComponents() {

		JToolBar toolBar = new JToolBar();

		JButton buttonWyszukajModel = new JButton("Wyszukaj Model");
		buttonWyszukajModel.setActionCommand("Model");
		buttonWyszukajModel.addActionListener(this);

		toolBar.add(buttonWyszukajModel);
		toolBar.addSeparator();

		JButton buttonDodajModel = new JButton("Dodaj Nowy Model");
		buttonDodajModel.setActionCommand("Dodaj");
		buttonDodajModel.addActionListener(this);

		toolBar.add(buttonDodajModel);

		add(toolBar, BorderLayout.NORTH);
		initBd();

	}
	
public void initBd() {
		
		GridLayout layout = new GridLayout(0,1);
		
		pole = new JPanel();
		
		// ustawiam domyslne bilae tlo
        pole.setBackground(new java.awt.Color(255, 255, 255));
        pole.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        pole.setLayout(layout);
        pole.setPreferredSize(new Dimension(550, 100));
        
        GridLayout layout2 = new GridLayout(0,5);
        
        JPanel polaczenie = new JPanel();
        polaczenie.setLayout(layout2);
        
        cena = new TextField();
        cena.setText("Podaj cene");
        cena.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				if (cena.getText().length() == 0){
					cena.setText("Podaj cene");
					cenaFlaga = false;
				}
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				if (cenaFlaga  == false){
					cena.setText("");
					cenaFlaga = true;
				}
			}
		});
        
        zegarProcesora = new TextField();
        zegarProcesora.setText("Zegar Procesora");
        zegarProcesora.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				if(zegarProcesora.getText().length() == 0){
					zegarProcesora.setText("Zegar Procesora");
					zegarFlaga = false;
				}
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				if (zegarFlaga == false){
					zegarProcesora.setText("");
					zegarFlaga = true;
				}
			}
		});
        
        pamiec = new TextField();
        pamiec.setText("Pamiec Wbudowana");
        pamiec.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				if(pamiec.getText().length() == 0){
					pamiec.setText("Pamiec Wbudowana");
					pamiecFlaga = false;
				}
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				if( pamiecFlaga == false){
					pamiec.setText("");
					pamiecFlaga = true;
				}
			}
		});
        
        przekatna = new TextField();
        przekatna.setText("Przekatna Ekranu");
        przekatna.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				if(przekatna.getText().length() == 0){
					przekatna.setText("Przekatna Ekranu");
					przekatnaFlaga = false;
				}
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				if(przekatnaFlaga == false){
					przekatna.setText("");
					przekatnaFlaga = true;
				}
			}
		});
        
        ram = new TextField();
        ram.setText("Pamiec RAM");
        ram.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				if (ram.getText().length() == 0){
					ram.setText("Pamiec RAM");
					ramFlaga = false;
				}
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				if(ramFlaga == false){
					ram.setText("");
					ramFlaga = true;
				}
			}
		});
    
      
        polaczenie.add(cena);
        polaczenie.add(zegarProcesora);
        polaczenie.add(pamiec);
        polaczenie.add(przekatna);
        polaczenie.add(ram);
        
        pole.add(polaczenie);
        
        wynik = new JTextPane();
        wynik.setEditable(false);
        pole.add(wynik);
        
		JButton button = new JButton("WYSZUKAJ");
		button.setActionCommand("wyszukaj");
		button.addActionListener(this);
		pole.add(button);
		
		add(pole);
        
		pack();
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {

		// TODO Auto-generated method stub
		String cmd = e.getActionCommand();
		try {
			Method m = this.getClass().getDeclaredMethod(cmd);
			m.invoke(this);// wywo�anie metody

		} catch (Exception exc) {
			exc.printStackTrace();
		}
	}
	
	public void wyszukaj(){
		
		double cenaDouble = Double.valueOf(cena.getText());
		double zegarProcesotaDouble = Double.valueOf(zegarProcesora.getText());
		double pamiecDouble = Double.valueOf(pamiec.getText());
		double przekatnaDouble = Double.valueOf(przekatna.getText());
		double ramDouble = Double.valueOf(ram.getText());
		double[] szukanyTelefon = new double[] {cenaDouble,zegarProcesotaDouble,pamiecDouble,przekatnaDouble,ramDouble};
		KNN knnsearch = new KNN();
		wynik.setText(knnsearch.wyszukajModel(szukanyTelefon));
		
		//ustawianie obiektu do usuniecia
		knnsearch = null;
	}

	public static void main(String arg[]) throws ClassNotFoundException, InstantiationException, IllegalAccessException,
			UnsupportedLookAndFeelException, SQLException, IOException {

		for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
			if ("Nimbus".equals(info.getName())) {
				UIManager.setLookAndFeel(info.getClassName());
				break;
			}
			new MainGUI();
		}
	}

}
